<?php

function custom_post_form_submit() {

    $description = isset($_POST['description']);
    $link = isset($_POST['post_link']) ? $_POST['post_link'] : array();
    $custom_categories = isset($_POST['custom_categories']) ? $_POST['custom_categories'] : array();
    $custom_images = isset($_FILES['custom_images']) ? $_FILES['custom_images'] : array();

    $post_data = array(
        'post_title' => 'Custom Post',
        'post_content' => $_POST['description'],
        'post_status' => 'publish',
        'post_type' => 'mypost',
        'post_category'=> $_POST['custom_categories'],
        'post_image'=> $_POST['custom_images'],
        'post_link'=>$_POST['link']
    );

    $post_id = wp_insert_post($post_data);

    // Add post link as anchor tag if provided
    if (!empty($_POST['post_link'])) {
        $post_content = get_post_field('post_content', $post_id);
        $post_content .= '<a href="' . $_POST['post_link'] . '">' . $_POST['post_link'] . '</a>';
        wp_update_post(array('ID' => $post_id, 'post_content' => $post_content));
    }

    // Upload images
    if (!empty($_FILES['images'])) {
        $uploaded_images = array();
        foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
            $upload_file = wp_handle_upload($_FILES['images'], array('test_form' => false));
            if ($upload_file && !isset($upload_file['error'])) {
                $attachment = array(
                    'post_mime_type' => $upload_file['type'],
                    'post_title' => sanitize_file_name($upload_file['file']),
                    'post_content' => '',
                    'post_status' => 'inherit',
                    'guid' => $upload_file['url']
                );
                $attachment_id = wp_insert_attachment($attachment, $upload_file['file'], $post_id);
                if (!is_wp_error($attachment_id)) {
                    $uploaded_images[] = $attachment_id;
                }
            }
        }
        set_post_thumbnail($post_id, $uploaded_images[0]);
    }

    // Assign categories
    if (!empty($_POST['custom_categories'])) {
        wp_set_post_categories($post_id, $_POST['custom_categories']);
    }

    echo json_encode(array('success' => true));
    wp_die();
}
add_action('wp_ajax_custom_post_form_submit', 'custom_post_form_submit');
add_action('wp_ajax_nopriv_custom_post_form_submit', 'custom_post_form_submit');




















?>
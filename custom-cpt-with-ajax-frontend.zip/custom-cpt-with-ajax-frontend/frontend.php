<?php

function custom_post_form_shortcode() {
    ob_start();
    ?>
    <div class="custom-post-form">
        <form id="custom-post-form" enctype="multipart/form-data">
            <label for="description">Description:</label><br>
            <textarea id="description" name="description" rows="4" cols="50"></textarea><br>

            <label for="post_link">Post Link:</label><br>
            <input type="text" id="post_link" name="post_link"><br>
            <div id="convertedLink"></div>

            <label for="images">Images:</label><br>
            <input type="file" id="images" name="images[]" multiple><br>
            <button type="submit">Upload</button>

                <label> Music Categories:</label><br>
                <?php
               $custom_categories = get_terms(array(
                'taxonomy' => 'music', // Replace 'your_taxonomy_name' with the actual taxonomy name
                
                'hide_empty' => false, // Set to true if you want to hide empty categories
            ));
            
            if (!empty($custom_categories) && !is_wp_error($custom_categories)) {
                foreach ($custom_categories as $category) {
                    echo '<input type="checkbox" name="custom_categories[]" value="' . $category->term_id . '"> ' . $category->name . '<br>';
                }
            }
            
                ?>
                <label> Fitness Categories:</label><br>
                <?php
               $custom_categories = get_terms(array(
                'taxonomy' => 'fitness', // Replace 'your_taxonomy_name' with the actual taxonomy name
                
                'hide_empty' => false, // Set to true if you want to hide empty categories
            ));
            
            if (!empty($custom_categories) && !is_wp_error($custom_categories)) {
                foreach ($custom_categories as $category) {
                    echo '<input type="checkbox" name="custom_categories[]" value="' . $category->term_id . '"> ' . $category->name . '<br>';
                }
            }
            
                ?>

            <input type="submit" value="Submit">
        </form>
        <div id="imagePreview"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('custom_post_form', 'custom_post_form_shortcode');


?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
//code for convert anchor tag to link
$(document).ready(function() {
    $('#linkInput').on('input', function() {
        var link = $(this).val();
        $('#convertedLink').html('<a href="' + link + '">' + link + '</a>');
    });
});

//image upload multiple
$(document).ready(function() {
    $('#imageUploadForm').on('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: my_script_vars.plugin_dir_url + '/images',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                $('#imagePreview').html(response);
            }
        });
    });
});


jQuery(document).ready(function($) {
    $('#custom_post_form_submit').on('submit', function(event) {
        event.preventDefault();

        var formData = new FormData($(this)[0]);

        $.ajax({
            url: wp-admin/admin-ajax.php, // WordPress AJAX endpoint
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                console.log(response);
                // Handle success response
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                // Handle error response
            }
        });
    });
});

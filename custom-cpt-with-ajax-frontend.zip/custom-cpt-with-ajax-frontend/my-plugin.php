<?php
/**
  * Plugin Name: My Plugin Interview Task
 * Author: Krishna Singh
 * Version: 1.0.0
 * Description: Create custom post type and Add Categories like music, fitness, etc.
 * Plugin URI: https://github.com/krisitpw
 * License: GPLv2
 */


 function enqueue_custom_scripts() {
    wp_enqueue_script('custom-post-form-script', plugin_dir_url(__FILE__) . 'js/custom-post-form.js', array('jquery'), null, true);
    wp_localize_script( 'custom-post-form-script', 'my_script_vars', array(
        'plugin_dir_url' => plugin_dir_url( __FILE__ ),
    ) );
}
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');



function custom_post_plugin_activate() {
    create_mypost_custom_post_type();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'custom_post_plugin_activate' );

function custom_post_plugin_deactivate() {
    unregister_post_type( 'custom_product' );
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'custom_post_plugin_deactivate' );

include_once(plugin_dir_path(__FILE__) . 'frontend.php');
include_once(plugin_dir_path(__FILE__) . 'custom-form-submit.php');

function create_mypost_custom_post_type() {
    $labels = array(
        'name'               => 'MyPosts',
        'singular_name'      => 'MyPost',
        'menu_name'          => 'MyPosts',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New MyPosts',
        'edit_item'          => 'Edit MyPost',
        'new_item'           => 'New MyPost',
        'view_item'          => 'View MyPost',
        'search_items'       => 'Search MyPosts',
        'not_found'          => 'No MyPosts found',
        'not_found_in_trash' => 'No MyPosts found in trash',
        'parent_item_colon'  => 'Parent MyPost:',
        'all_items'          => 'All MyPosts',
    );

    $args = array(
        'labels'        => $labels,
        'public'        => true,
        'has_archive'   => true,
        'menu_icon'     => 'dashicons-admin-media',
        'supports'      => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite'       => array('slug' => 'mypost'),
    );

    register_post_type('mypost', $args);
}

add_action('init', 'create_mypost_custom_post_type');

function create_music_taxonomy() {
    $labels = array(
        'name'              => 'Musics',
        'singular_name'     => 'Music',
        'search_items'      => 'Search Musics',
        'all_items'         => 'All Musics',
        'parent_item'       => 'Parent Music',
        'parent_item_colon' => 'Parent Music:',
        'edit_item'         => 'Edit Music',
        'update_item'       => 'Update Music',
        'add_new_item'      => 'Add New Music',
        'new_item_name'     => 'New SiMusic Name',
        'menu_name'         => 'Music',
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'music'),
    );

    register_taxonomy('music', array('mypost'), $args);
}

add_action('init', 'create_music_taxonomy');

function create_fitness_taxonomy() {
    $labels = array(
        'name'              => 'Fitnesss',
        'singular_name'     => 'fitness,',
        'search_items'      => 'Search Fitnesss',
        'all_items'         => 'All Fitnesss',
        'parent_item'       => 'Parent Fitness',
        'parent_item_colon' => 'Parent Fitness:',
        'edit_item'         => 'Edit Fitness',
        'update_item'       => 'Update Fitness',
        'add_new_item'      => 'Add New Fitness',
        'new_item_name'     => 'New Fitness Name',
        'menu_name'         => 'Fitness',
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'fitness'),
    );

    register_taxonomy('fitness', array('mypost'), $args);
}

add_action('init', 'create_fitness_taxonomy');







// function custom_post_form_submit() {
//     // $post_title = sanitize_text_field($_POST['post_title']);
//     $description = wp_kses_post($_POST['description']);
//     $custom_categories = isset($_POST['custom_categories']) ? $_POST['custom_categories'] : array();
//     $custom_images = isset($_FILES['custom_images']) ? $_FILES['custom_images'] : array();

//     // Create post object
//     $new_post = array(
//         // 'post_title'    => $post_title,
//         'post_content'  => $description,
//         'post_status'   => 'publish',
//         'post_type'     => 'mypost', // Change to your custom post type if applicable
//     );

//     // Insert the post into the database
//     $post_id = wp_insert_post($new_post);

//     // Assign categories to the post
//     if (!empty($custom_categories)) {
//         wp_set_post_categories($post_id, $custom_categories);
//     }

//     // Upload images and attach to the post
//     if (!empty($custom_images)) {
//         foreach ($custom_images['tmp_name'] as $key => $tmp_name) {
//             $upload_file = wp_handle_upload($custom_images, array('test_form' => false));
//             if ($upload_file && !isset($upload_file['error'])) {
//                 $attachment = array(
//                     'post_mime_type' => $upload_file['type'],
//                     'post_title' => sanitize_file_name($upload_file['file']),
//                     'post_content' => '',
//                     'post_status' => 'inherit',
//                     'guid' => $upload_file['url']
//                 );
//                 $attachment_id = wp_insert_attachment($attachment, $upload_file['file'], $post_id);
//                 if (!is_wp_error($attachment_id)) {
//                     set_post_thumbnail($post_id, $attachment_id);
//                 }
//             }
//         }
//     }

//     if ($post_id) {
//         echo json_encode(array('success' => true, 'message' => 'Post submitted successfully.'));
//     } else {
//         echo json_encode(array('success' => false, 'message' => 'Failed to submit post.'));
//     }

//     wp_die();
// }
// add_action('wp_ajax_custom_post_form_submit', 'custom_post_form_submit');
// add_action('wp_ajax_nopriv_custom_post_form_submit', 'custom_post_form_submit');



?>